library(testthat)
library(RcppProgress)

test_check("RcppProgress")
