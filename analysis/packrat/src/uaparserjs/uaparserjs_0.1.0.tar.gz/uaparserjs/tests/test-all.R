library(testthat)
test_check("uaparserjs")
