#' Parse Browser User Agent Strings into Data Frames
#'
#' @name uaparserjs
#' @docType package
#' @author Bob Rudis (@@hrbrmstr)
#' @importFrom purrr map map_df
#' @import V8
#' @importFrom dplyr as_data_frame progress_estimated
NULL
