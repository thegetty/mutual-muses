library(testthat)
library(bootr)

test_check("bootr")
