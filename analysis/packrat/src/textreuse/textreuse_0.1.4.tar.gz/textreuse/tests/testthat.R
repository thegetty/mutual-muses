library(testthat)
library(textreuse)

test_check("textreuse")
