globalVariables(c("X1", "X2", "X3", "word", "code", "category", "texts",
                  "i", "j", "x", "Var1", "Var2", "value",
                  ".ndocs", ".nterm", ".document_total",
                  "tf", "idf", "sentiments", "document", "term"))
